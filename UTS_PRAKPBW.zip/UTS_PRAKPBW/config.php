<?php

$con = mysqli_connect('localhost', 'root','','prak_pbw');

?>